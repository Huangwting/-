package com.zudui;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZuApplicationTests {

    @Test
    void contextLoads() {
    }

}
