package com.zudui.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.zudui.model.entity.BmsTag;
import org.springframework.stereotype.Repository;


@Repository
public interface BmsTagMapper extends BaseMapper<BmsTag> {

}
